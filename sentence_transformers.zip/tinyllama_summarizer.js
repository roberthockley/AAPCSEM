// summarizeWithTinyLlama.js

import path from "path";
import { fileURLToPath } from "url";
import { getLlama, LlamaChatSession } from "node-llama-cpp";

// Setup __dirname manually in ESM
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const MODEL_PATH = path.join(__dirname, "tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf");

let session = null;

async function loadSession() {
  if (!session) {
    const llama = await getLlama();
    const model = await llama.loadModel({
      modelPath: MODEL_PATH,
      nCtx: 2048,
      seed: 42,
    });
    const context = await model.createContext();
    session = new LlamaChatSession({ contextSequence: context.getSequence() });
  }
}

export async function summarizeWithTinyLlama(query, answer) {
  await loadSession();

const prompt = `User asked: "${query}"\nKnowledge base answer: "${answer}"\n\n
Summarize in a concise, user-friendly response that directly answers the user's question:\n\nSummary:`;

  const result = await session.prompt(prompt);
  return result.trim();
}

// === Test Run ===
const result = await summarizeWithTinyLlama(
  "how many members are there in ncss",
  "The National Council of Social Service (NCSS) is the umbrella body for over 500-member social service agencies in Singapore. Its mission is to provide leadership and direction in enhancing the capabilities and capacity of our members, advocating for social service needs and strengthening strategic partnerships, for an effective social service ecosystem."
);

console.log("Refined summary:", result);


// let result = '';
// await session.prompt(prompt, {
//   onToken: (token) => {
//     result += token;
//     process.stdout.write(token); // stream it live
//   }
// });