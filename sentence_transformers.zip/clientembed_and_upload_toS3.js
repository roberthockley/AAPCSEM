// generate_faq_embeddings.js
import { S3Client, GetObjectCommand, PutObjectCommand } from '@aws-sdk/client-s3';
import csv from 'csv-parser';
import { pipeline } from '@xenova/transformers';
import { Buffer } from 'buffer';

// === Configuration ===
const BUCKET = 'song-ai-dhl2';
const INPUT_KEY = 'DHL_FAQ_clean.csv';
const OUTPUT_PREFIX = 'embeddings/';
const REGION = 'ap-southeast-2';

// === AWS S3 Setup ===
const s3 = new S3Client({ region: REGION });

// === Load and parse CSV from S3 ===
async function loadCSVFromS3(bucket, key) {
  const command = new GetObjectCommand({
    Bucket: bucket,
    Key: key,
  });

  const response = await s3.send(command);
  const stream = response.Body;

  return new Promise((resolve, reject) => {
    const results = [];
    stream
      .pipe(csv())
      .on('data', (data) => results.push(data))
      .on('end', () => resolve(results))
      .on('error', reject);
  });
}

// === Group data by client name ===
function groupByClient(rows) {
  const grouped = {};
  for (const row of rows) {
    const client = row.Client || 'DHL';
    if (!grouped[client]) grouped[client] = [];
    grouped[client].push(row);
  }
  return grouped;
}

// === Upload JSON to S3 ===
async function uploadJSONToS3(key, json) {
  const command = new PutObjectCommand({
    Bucket: BUCKET,
    Key: key,
    Body: Buffer.from(json),
    ContentType: 'application/json',
  });
  await s3.send(command);
}

// === Main Function ===
(async () => {
  try {
    console.log("Loading embedding model...");
    const extractor = await pipeline('feature-extraction', 'Xenova/bge-base-en-v1.5');
    console.log("Embedding model ready.");

    console.log("Reading CSV from S3...");
    const csvData = await loadCSVFromS3(BUCKET, INPUT_KEY);
    const grouped = groupByClient(csvData);

    for (const client of Object.keys(grouped)) {
      console.log(`Processing client: ${client}`);
      const records = [];

      for (const row of grouped[client]) {
        const question = (row.Question || '').toString().trim();
        const answer = (row.Answer || '').toString().trim();

        if (!question || !answer) continue;

        const combinedText = `Q: ${question}\nA: ${answer}`;

        const result = await extractor(combinedText, {
          pooling: 'mean',
          normalize: true,
        });

        const metadata = {
          Client: row.Client || client,
          Category: row.Category || '',
        };

        records.push({
          embedding: Array.from(result.data),
          metadata,
          question,
          answer,
        });
      }

      const json = JSON.stringify(records, null, 2);
      const outputKey = `${OUTPUT_PREFIX}${client}_FAQ3.json`;

      await uploadJSONToS3(outputKey, json);
      console.log(`Uploaded: ${outputKey} (${records.length} records)`);
    }
  } catch (error) {
    console.error("Error:", error);
  }
})();
